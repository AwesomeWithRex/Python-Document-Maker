# Docs
![](Images/DocMaker.png)
## contents
[Instructions](#instructions/building)
[Text To HTML](#basic-text-to-html)

## basic-text-to-html
This is another super small project. All it does is take text from an text file and converts it into a basic html file

## instructions/building
(MUST HAVE PYTHON FOR IT TO WORK)
Edit the text.txt file to your doc
then double click main.py
then it should work!